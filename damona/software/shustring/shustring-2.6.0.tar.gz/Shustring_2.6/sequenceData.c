/***** sequenceData.c *********************************************
 * Description: Collection of routines for reading and 
 * manipulating sequence data.
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Sun Jun  6 10:34:31 2004.
 *
 * This file is part of shustring.
 *
 *   Shustring is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   Shustring is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with shustring; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *****************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include "DeepShallow/common.h"
#include "sequenceData.h"
#include "stringUtil.h"
#include "eprintf.h"


static int lastSequence = 0;
static char *line = NULL;

/* convertToACGT: convert nucleotide data to acgt alphabet.
 */
void convertToAcgt(Sequence *seq){
  Int64 numCorr, i, j, min;
  char dic[DICSIZE];
  char *tmpSeq;

  seq->pos = (Int64 *)emalloc(seq->len*sizeof(Int64));
  tmpSeq = (char *)emalloc((seq->len+1)*sizeof(char));

  for(i=0;i<DICSIZE;i++)
    dic[i] = 0;
  dic['A'] = 1;
  dic['C'] = 1;
  dic['G'] = 1;
  dic['T'] = 1;
  dic['a'] = 1;
  dic['c'] = 1;
  dic['g'] = 1;
  dic['t'] = 1;

  numCorr = 0;
  for(i=0;i<seq->numSeq;i++){
    if(i)
      min = seq->borders[i-1]+1;
    else
      min = 0;
    for(j=min;j<seq->borders[i];j++)
      if(dic[(int)seq->seq[j]]){
	seq->pos[numCorr] = j;
	tmpSeq[numCorr] = (char)seq->seq[j];
	numCorr++;
      }
    seq->borders[i] = numCorr;
  }
  for(i=0;i<numCorr;i++)
    seq->seq[i] = tmpSeq[i];
  seq->seq = (char *)erealloc(seq->seq,(numCorr+1)*sizeof(char));
  seq->seq[numCorr] = '\0';
  seq->len = numCorr;
  seq->pos = (Int64 *)erealloc(seq->pos,numCorr*sizeof(Int64));
  free(tmpSeq);
}

/* everything that is not [acgtACGT] is flagged by a -1 */
int *getRestrictedDnaDictionary(int *dic){
  int i;

  if(dic == NULL)
    dic = (int *)emalloc((DICSIZE+1)*sizeof(int));

  for(i=0; i<DICSIZE; i++)
    dic[i] = -1;

  dic['a'] = 0;   /* a */
  dic['c'] = 1;   /* c */
  dic['g'] = 2;   /* g */
  dic['t'] = 3;   /* t */
  dic['A'] = 0;   /* A */
  dic['C'] = 1;   /* C */
  dic['G'] = 2;   /* G */
  dic['T'] = 3;   /* T */

  return dic;

}

/* getDnaDictionary: create DNA dictionary */
int *getDnaDictionary(int *dic){
  int i;

  if(dic == NULL)
    dic = (int *)malloc((DICSIZE+1)*sizeof(int));

  for(i=0; i<DICSIZE; i++)
    dic[i] = 0;

  dic['a'] = 0;   /* a */
  dic['c'] = 1;   /* c */
  dic['g'] = 2;   /* g */
  dic['t'] = 3;   /* t */
  dic['A'] = 0;   /* A */
  dic['C'] = 1;   /* C */
  dic['G'] = 2;   /* G */
  dic['T'] = 3;   /* T */
  dic['r'] = dic['g'];
  dic['R'] = dic['g'];
  dic['y'] = dic['t'];
  dic['Y'] = dic['t'];
  dic['m'] = dic['a'];
  dic['M'] = dic['a'];
  dic['k'] = dic['g'];
  dic['K'] = dic['g'];
  dic['s'] = dic['g'];
  dic['S'] = dic['g'];
  dic['w'] = dic['a'];
  dic['W'] = dic['a'];
  dic['h'] = dic['a'];
  dic['H'] = dic['a'];
  dic['b'] = dic['g'];
  dic['B'] = dic['g'];
  dic['v'] = dic['g'];
  dic['V'] = dic['g'];
  dic['d'] = dic['g'];
  dic['D'] = dic['g'];
  dic['n'] = dic['g'];
  dic['N'] = dic['g'];
  dic['u'] = dic['t'];
  dic['U'] = dic['t'];

  return dic;
}


/* reverse and complement a sequence */
Sequence *revcomp(Sequence *seq){
  Int64 i,j,n;
  char c;
  Sequence *newSeq;
  newSeq = (Sequence *)emalloc(sizeof(Sequence));

  n = strlen(seq->seq);
  newSeq->seq = (char *) emalloc((n+1)*sizeof(char));

  newSeq->id = strdup2(seq->id);
  j=0;
  for(i = n-1; i >= 0; i--){
    c = seq->seq[i];
    switch(c){
      case '\1':
	newSeq->seq[j++] = '\1';
	break;
      case 'a':
	newSeq->seq[j++] ='t';
	break;
      case 'c':
	newSeq->seq[j++] ='g';
	break;
      case 'g':
	newSeq->seq[j++] ='c';
	break;
      case 't':
	newSeq->seq[j++] ='a';
	break;
      case 'A':
	newSeq->seq[j++] ='T';
	break;
      case 'C':
	newSeq->seq[j++] ='G';
	break;
      case 'G':
	newSeq->seq[j++] ='C';
	break;
      case 'T':
	newSeq->seq[j++] ='A';
	break;
      default:
	newSeq->seq[j++] =c;
	break;
    }
  }
  newSeq->seq[n]='\0';
  return newSeq; 
}
/* Get next sequence from an open data stream in FASTA format; this stream may be the stdin */
Sequence *getPermanentNextSequence(FILE *fp){
  Sequence *sequence;
  int seqlen, seqi, i, l;
  int currentBuffer;

  if(lastSequence){
    return NULL;
  }
  if(line == NULL){
    line = (char *)emalloc((SEQLINE+2)*sizeof(char));
    line = fgets(line,SEQLINE,fp);
  }
  /* make a sequence object */
  sequence = (Sequence *)emalloc(sizeof(Sequence));
  /* allocate memory for sequence id */
  sequence->id = (char *)emalloc((strlen(line)+1)*sizeof(char));
  /* copy sequence id */
  strcpy(sequence->id,chomp(line));
  /* allocate memory for sequence string */
  sequence->seq = (char *)emalloc((SEQBUFFER+1)*sizeof(char));
  seqlen = 0;
  currentBuffer = SEQBUFFER;
  seqi = 0;
  while((line=fgets(line,SEQLINE,fp)) != NULL){
    if(strstr(line,">") != NULL){
      sequence->seq[seqi++] = '\0';
      sequence->seq = (char *) realloc(sequence->seq, seqi * sizeof(char));
      return sequence;
    }
    if(strlen(line)>SEQLINE){
      printf("error in getNextSequence: cannot deal with lines longer than %d bp.\n",SEQLINE);
      printf("  change the SEQLINE parameter in file sequenceData.h and recompile.\n");
      exit(2);
    }
    l = strlen(line);
    /* disregard the final carriage return */
    if(line[l-1] == '\n')
      l--;
    seqlen += l; 
    if(seqlen > currentBuffer){
      currentBuffer += SEQBUFFER;
      sequence->seq = (char *)erealloc(sequence->seq,currentBuffer);
    }
    for(i=0;i<l;i++){
      sequence->seq[seqi++] = line[i];
    }
    /* sequence->seq = strncat(sequence->seq,line,strlen(line)-1); */
  }
  sequence->seq[seqi++] = '\0';
  sequence->seq = (char *) realloc(sequence->seq,seqi*sizeof(char));
  sequence->len = seqi - 1;
  lastSequence = 1;
  return sequence;
}

void resetSequenceReader(){
  line = NULL;
  lastSequence = 0;
}

/* Get next sequence from an open data stream in FASTA format; this stream may be the stdin */
Sequence *getNextSequence(FILE *fp){
  Sequence *sequence;
  int seqlen, seqi, i, l;
  int currentBuffer;

  if(lastSequence){
    return NULL;
  }

  if(line == NULL){
    line = (char *)malloc((SEQLINE+2)*sizeof(char));
    line = fgets(line,SEQLINE,fp);
  }

  /* make a sequence object */
  sequence = (Sequence *) malloc(sizeof(Sequence));
  sequence->numSeq = 1;
  sequence->borders = (Int64 *)emalloc(sizeof(Int64));
  /* allocate memory for sequence id */
  sequence->id = (char *)malloc((strlen(line)+1)*sizeof(char));
  /* copy sequence id */
  strcpy(sequence->id,line);
  /* allocate memory for sequence string */
  sequence->seq = (char *)malloc((SEQBUFFER+1)*sizeof(char));

  seqlen = 0;
  currentBuffer = SEQBUFFER;
  seqi = 0;
  while((line=fgets(line,SEQLINE,fp)) != NULL){
    if(strstr(line,">") != NULL){
      sequence->seq = (char *) realloc(sequence->seq,strlen(sequence->seq)+1);
      return sequence;
    }
    if(strlen(line)>SEQLINE){
      printf("error in getNextSequence: cannot deal with lines longer than %d bp.\n",SEQLINE);
      printf("  change the SEQLINE parameter in file sequenceData.h and recompile.\n");
      exit(2);
    }
    l = strlen(line);
    /* disregard the final carriage return */
    if(line[l-1] == '\n')
      l--;
    seqlen += l; 
    if(seqlen > currentBuffer){
      currentBuffer += SEQBUFFER;
      sequence->seq = (char *)erealloc(sequence->seq,currentBuffer);
    }
    for(i=0;i<l;i++){
      sequence->seq[seqi++] = line[i];
    }
    /* sequence->seq = strncat(sequence->seq,line,strlen(line)-1); */
  }
  sequence->seq = (char *) realloc(sequence->seq,(seqlen+1)*sizeof(char));
  sequence->borders[0] = seqlen;
  sequence->len = seqlen;
  lastSequence = 1;
  return sequence;
}


/* read FASTA-formatted sequence data from an open file descriptor */
Sequence *readFasta(int fd){
  Sequence *s;
  char *buf;
  Int64 headerOpen, c, maxLen;
  Int64 headerLen, i;

  buf = (char *)emalloc(BUFSIZ*sizeof(char));
  s = (Sequence *)emalloc(sizeof(Sequence));
  s->id = "SeqId\n";
  s->seq = NULL;
  s->borders = NULL;
  s->headers = NULL;
  headerOpen = 0;
  s->len = 0;
  s->numSeq = 0;
  maxLen = 0;
  headerLen = 0;
  while((c = read(fd,buf,BUFSIZ)) > 0){
    if(s->len + c > maxLen){
      if(maxLen >= BUFSIZ)
	maxLen *= 2;
      else
	maxLen = BUFSIZ + 1;
      s->seq = (char *)erealloc(s->seq,maxLen*sizeof(char));
    }
    for(i=0; i<c; i++){
      if(buf[i] == '>'){
	headerOpen = 1;
	/* take care of sequence borders */
	s->borders = (Int64 *)erealloc(s->borders,(s->numSeq+1)*sizeof(Int64));
	if(s->numSeq >= 1){
	  s->seq[s->len] = '\1';  /* unique character to terminate each sequence */
	  s->len++;
	  s->borders[s->numSeq-1] = s->len-1;
	}
	/* take care of sequence headers */
	s->headers = (char **)erealloc(s->headers,(s->numSeq+1)*sizeof(char *));
	s->headers[s->numSeq] = (char *)emalloc(BUFSIZ*sizeof(char));
	headerLen = 0;
	s->numSeq++;
      }
      if(headerOpen){
	if(buf[i] == '\n'){
	  headerOpen = 0;
	  s->headers[s->numSeq-1][headerLen] = '\0';
	  s->headers[s->numSeq-1] = (char *)erealloc(s->headers[s->numSeq-1],(headerLen+1)*sizeof(char));
	}
	else if(headerLen < BUFSIZ && isprint(buf[i]))
	  s->headers[s->numSeq-1][headerLen++] = buf[i];
      }else if(buf[i] != '\n'){
	s->seq[s->len] = buf[i];
	s->len++;
      }
    }
  }
  /* add last border */
  s->seq[s->len] = '\1';
  s->len++;
  /* set end of last sequence read */
  s->borders[s->numSeq - 1] = s->len - 1;
  /* trim sequence to actual size */
  s->seq = (char *)erealloc(s->seq,s->len*sizeof(char));
  return s;
}


/* freeSequence: free the data structure Sequence */
Sequence *freeSequence(Sequence *seq){
  free(seq->id);
  free(seq->seq);
  free(seq);
  return seq;
}
