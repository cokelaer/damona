/***** hash.c *****************************************************
 * Description: Searching for shustrings in DNA sequence using
 *   hashing
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Mon Apr 18 23:45:50 2005.
 *
 * This file is part of shustring.
 *
 *   Shustring is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   Shustring is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with shustring; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *****************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <limits.h>
#include "DeepShallow/common.h"
#include "interface.h"
#include "sequenceData.h"
#include "stringUtil.h"
#include "shustring.h"
#include "hash.h"
#include "eprintf.h"

void runHash(Args args){
  ShustringResult *result = NULL;
  printf("# Reading data from file & hashing sequence...\n");
  if(args.f > 0)                                    /* constant word length */
    result = constantHash(args);
  else
    result = iterativeHash(args);                   /* unknown word length */
  printf("#                                             done.\n");
  if(result != NULL){
    result->isUpper = 1;                           /* search is case-insensitive, output is upper case */
/*     setCase(args, result); */
    outputHash(result, args);
    if(args.o != NULL)
      printf("# Results written to file %s\n",args.o);
  }else{
    printf("# No shustrings found\n");
  }
}

/* iterativeHash: find shustrings of unknown length by hash method */
ShustringResult *iterativeHash(Args args){
  FILE *fp;
  ShustringResult *result;
  Sequence *seq, *revSeq;
  int numUnique = 0;
  int namesSize = 1;
  CountTable *countTable;
  int i, rev, seqid;

  namesSize = 1;
  fp = efopen(args.i,"r");
  countTable = (CountTable *)emalloc(sizeof(CountTable));
  result = (ShustringResult *)emalloc(sizeof(ShustringResult));
  result->names = (char **)emalloc(namesSize*sizeof(char *));
  result->strLengths = (Int64 *)emalloc(namesSize*sizeof(Int64));
  result->numStrings = 0;
  countTable->wordLen = 1;
  countTable->size = pow(4,countTable->wordLen);
  countTable->array = (Count *)emalloc(countTable->size*sizeof(Count));
  initializeCountTable(countTable);
  /* find shustring length for entire set of strings */
  while(1){
    if((seq = getNextSequence(fp)) == NULL)
      break;
    if((result->numStrings+1) >= namesSize){
      namesSize *= 2;
      result->names = (char **)erealloc(result->names,(namesSize+1)*sizeof(char *));
      result->strLengths = (Int64 *)erealloc(result->strLengths,(namesSize+1)*sizeof(Int64));
    }
    if(!args.u){
      convertToAcgt(seq);
    }
    result->names[result->numStrings] = strdup(seq->id);
    result->strLengths[result->numStrings] = strlen(seq->seq);
    rev = 0;
    countUniqueWords(countTable, seq->seq, result->numStrings, numUnique, rev);
    result->numStrings++;
    if(countTable->occupancy < countTable->size && args.r){
      revSeq = revcomp(seq);
      result->names[result->numStrings] = strdup(revSeq->id);
      result->strLengths[result->numStrings] = strlen(revSeq->seq);
      rev = 1;
     countUniqueWords(countTable, revSeq->seq, result->numStrings, numUnique, rev);
      result->numStrings++;
      freeSequence(revSeq);
    }
    freeSequence(seq);
    if(countTable->occupancy == countTable->size){
      rewind(fp);
      resetSequenceReader();
      result->numStrings = 0;
      countTable->wordLen++;
      countTable-> size = pow(4,countTable->wordLen);
      countTable->array = (Count *)erealloc(countTable->array,countTable->size*sizeof(Count));
      initializeCountTable(countTable);
    }
  }
  result->names = (char **)erealloc(result->names,result->numStrings*sizeof(char *));
  /* prepare the array of pointers to shustring lists in the result structure */
  result->shustrings = (Shustring **)emalloc(result->numStrings*sizeof(Shustring));
  for(i=0;i<result->numStrings;i++){
    result->shustrings[i] = (Shustring *)emalloc(sizeof(Shustring));
    result->shustrings[i]->next = NULL;
  }
  /* prepare the array of shustring counts in the result structure */
  result->coverIndex = (short *)emalloc(result->numStrings*sizeof(short));
  result->numShustrings = (Int64 *)emalloc(result->numStrings*sizeof(Int64));
  for(i=0;i<result->numStrings;i++){
    result->coverIndex[i] = 0;
    result->numShustrings[i] = 0;
  }
  collectShustrings(countTable, result);
  /* find shustring lengths for strings not yet covered by >= 1 shustring */
  while(result->numCovered < result->numStrings){
    rewind(fp);
    resetSequenceReader();
    seqid = 0;
    countTable->wordLen++;  
    countTable->size = pow(4,countTable->wordLen);
    countTable->array = (Count *)erealloc(countTable->array,countTable->size*sizeof(Count));
    initializeCountTable(countTable);  
    while((seq = getNextSequence(fp)) != NULL){
      rev = 0;
      if(!args.u)
	convertToAcgt(seq);
      numUnique = countUniqueWords(countTable, seq->seq, seqid++, numUnique, rev);
      if(countTable->occupancy == countTable->size)
	break;
      if(args.r){
	rev = 1;
	revSeq = revcomp(seq);
	numUnique = countUniqueWords(countTable, revSeq->seq, seqid++, numUnique, rev);
	freeSequence(revSeq);
	if(countTable->occupancy == countTable->size)
	  break;
      }
      freeSequence(seq);
    }
    collectShustrings(countTable, result);
  }
  free(countTable->array);
  return result;
}

/* constantHash: find shustrings by hash method based on constant length of hashkey */
ShustringResult *constantHash(Args args){
  FILE *fp;
  ShustringResult *result;
  Sequence *seq, *revSeq;
  int numUnique = 0;
  int namesSize = 1;
  CountTable *countTable;
  int i, rev;

  namesSize = 1;
  fp = efopen(args.i,"r");
  countTable = (CountTable *)emalloc(sizeof(CountTable));
  countTable->array = (Count *)emalloc(pow(4,args.f)*sizeof(Count));
  result = (ShustringResult *)emalloc(sizeof(ShustringResult));
  result->names = (char **)emalloc(namesSize*sizeof(char *));
  result->strLengths = (Int64 *)emalloc(namesSize*sizeof(Int64));
  result->numStrings = 0;
  countTable->wordLen = args.f;
  initializeCountTable(countTable);
  while((seq = getNextSequence(fp)) != NULL){
    if((result->numStrings+1) >= namesSize){
      namesSize *= 2;
      result->names = (char **)erealloc(result->names,namesSize*sizeof(char *));
      result->strLengths = (Int64 *)erealloc(result->strLengths,namesSize*sizeof(Int64));
    }
    result->names[result->numStrings] = strdup(seq->id);
    result->strLengths[result->numStrings] = strlen(seq->seq);
    rev = 0;
    if(!args.u)
      convertToAcgt(seq);
    countUniqueWords(countTable, seq->seq, result->numStrings, numUnique, rev);
    if(countTable->occupancy == countTable->size)
      return NULL;
    result->numStrings++;
    if(args.r){
      rev = 1;
      revSeq = revcomp(seq);
      result->names[result->numStrings] = strdup(revSeq->id);
      result->strLengths[result->numStrings] = strlen(revSeq->seq);
      countUniqueWords(countTable, revSeq->seq, result->numStrings, numUnique, rev);
      if(countTable->occupancy == countTable->size){
	return NULL;
      }
      result->numStrings++;
      freeSequence(revSeq);
    } 
    freeSequence(seq);
  }
  fclose(fp);
  result->names = (char **)erealloc(result->names,result->numStrings*sizeof(char *));
  /* prepare the array of pointers to shustring lists in the result structure */
  result->shustrings = (Shustring **)emalloc(result->numStrings*sizeof(Shustring));
  for(i=0;i<result->numStrings;i++){
    result->shustrings[i] = (Shustring *)emalloc(sizeof(Shustring));
    result->shustrings[i]->next = NULL;
  }
  /* prepare the array of shustring counts in the result structure */
  result->coverIndex = (short *)emalloc(result->numStrings*sizeof(short));
  result->numShustrings = (Int64 *)emalloc(result->numStrings*sizeof(Int64));
  for(i=0;i<result->numStrings;i++){
    result->coverIndex[i] = 0;
    result->numShustrings[i] = 0;
  }
  collectShustrings(countTable, result);
  return result;
}


/* countUniqueWords: core hash routine; fills in the hash array in "table"
 * and returns the number of unique words given an initial number of 
 * uniques; assumes that both "table" and "table->array" have been allocated
 */
int countUniqueWords(CountTable *table, char *str, int seqid, int numUnique, int rev){
  int k, w, i, c, wordLen, totalLen;
  int *power;
  int *dic = NULL;
  Count *array;

  array = table->array;

  wordLen = table->wordLen;
  power = (int *)emalloc((wordLen+1)*sizeof(int));
  dic = getRestrictedDnaDictionary(dic);

  c = wordLen+1;
  for(i=0;i<c;i++)
    power[i] = pow(4,i);

  k = 0;
  w = 0;
  totalLen = strlen(str)+1;
  i = 0;
  while(i+k <= totalLen && i < totalLen){
    /* make sure that only words consisting of acgt or ACGT are considered */
    if((c = dic[(int)str[i]]) < 0){
      k = 0;
      w = 0;
    }else{
      w = 4*(w % power[k++]) + c; 
    }
    if(k == wordLen){
      if(table->array[w].count == 0){  
	if(rev){
	  table->array[w].isForward = 0;
	  table->array[w].position = totalLen - i - 1;
	}else{
	  table->array[w].isForward = 1;
	  table->array[w].position = i - k + 2;
	}
	table->array[w].stringId = seqid;
	table->array[w].len = wordLen;
	numUnique++;
	table->array[w].count++;
      }else if(array[w].count == 1){                     /* hit a hitherto unique string */
	table->occupancy++;
	numUnique--;
	table->array[w].count++;
      }
      k--;
    }
    i++;
  }
  free(power);
  free(dic);
  return numUnique;
}

/* collectShustrings: using table as input, store the corresponding
 * shustrings in result and return the number of string not covered
 * by shustrings yet
 */
int collectShustrings(CountTable *table, ShustringResult *result){
  int i, arrayLength;
  Shustring *sh;                         /* pointer to single shustring */
  Shustring **shustringStart;            /* array of pointers to start of shustring lists */

  arrayLength = pow(4,table->wordLen);
  shustringStart = (Shustring **)emalloc(result->numStrings*sizeof(Shustring));
  /* store start positions of shustring lists */
  for(i=0;i<result->numStrings;i++)
    shustringStart[i] = result->shustrings[i];
  
  for(i=0;i<arrayLength;i++){
    if(table->array[i].count == 1 && !result->coverIndex[table->array[i].stringId]){
      sh = (Shustring *)emalloc(sizeof(Shustring));
      sh->next = NULL;
      sh->pos = table->array[i].position;
      sh->stringId = table->array[i].stringId;
      sh->len = table->array[i].len;
      sh->word = i;
      sh->isForward = table->array[i].isForward;
      result->shustrings[sh->stringId]->next = sh;
      result->shustrings[sh->stringId] = result->shustrings[sh->stringId]->next;
      result->numShustrings[sh->stringId]++;
    }
  }
  /* restore shustring lists to their start positions */
  for(i=0;i<result->numStrings;i++)
    result->shustrings[i] = shustringStart[i];
  /* accounting of strings covered by shustrings */
  result->numCovered = 0;
  for(i=0;i<result->numStrings;i++){
    if(result->shustrings[i]->next != NULL){
      result->coverIndex[i] = 1;
      result->numCovered++;
    }else
      result->coverIndex[i] = 0;
  }
  return result->numStrings-result->numCovered;
}



/* initializeCountTable: initialize the counts in the table to zero */
void initializeCountTable(CountTable *table){
  int i;
  
  table->occupancy = 0;
  for(i=0;i<table->size;i++){
    table->array[i].count = 0;
  }
}

/* convert number to string */
char *num2str(int word, int wordLength, char *dic, char *str){
  int i, j, a;

  j = wordLength-1;
  for(i=wordLength-1;i>=0;i--){
    a = word/pow((double)4,(double)i);
    str[j--] = dic[a];
    word -= a*pow((double)4,(double)i);
  }
  str[wordLength] = '\0';
  return str;
}

void setCase(Args args, ShustringResult *result){
  FILE *fp;
  char *line;
  int lineLength = MAXLINE;

  line = (char *)emalloc((lineLength+1)*sizeof(char));
  fp = efopen(args.i,"r");
  line = fgets(line, lineLength, fp);
  line = fgets(line, lineLength, fp);
  if(isupper(line[0]))
    result->isUpper = 1;
  else
    result->isUpper = 0;
  free(line);
  fclose(fp);
}

void outputHash(ShustringResult *result, Args args){
  Shustring **shustringArr;
  FILE *fpout;
  int i, j;
  char *str = NULL;
  char *alphabet;

  if(result->isUpper)
    alphabet = "ACGT";
  else
    alphabet = "acgt";

  if(args.o == NULL)
    fpout = stdout;
  else
    fpout = efopen(args.o,"w");
  if(args.q == 2)
    fprintf(fpout,"# seqId\tseqlen\tnumshu\tshulen");
  for(i=0;i<result->numStrings;i++){
    if(result->shustrings[i]->next == NULL)
      continue;
    if(!result->shustrings[i]->next->isForward)
      continue;
    fprintf(fpout,"# ");
    fprintnf(fpout,result->names[i],NAMELENGTH);
    if(!result->shustrings[i]->next->isForward)
      fprintf(fpout,"-R"); 
    fprintf(fpout,"\t%ld",result->strLengths[i]);
    fprintf(fpout,"\t%ld",result->numShustrings[i]);
    if(args.f < 0)
      fprintf(fpout,"\t%ld",result->shustrings[i]->next->len);
    else
      fprintf(fpout,"\t%ld",result->shustrings[i]->next->len);
    fprintf(fpout,"\n");
    fprintf(fpout,"# num\t");
    fprintf(fpout,"pos\t");
    if(args.q == 0)
      fprintf(fpout,"seq");
    fprintf(fpout,"\n");
    shustringArr = (Shustring **)emalloc(result->numShustrings[i]*sizeof(Shustring));
    for(j=0;j<result->numShustrings[i];j++){
      shustringArr[j] = result->shustrings[i]->next;
      result->shustrings[i] = result->shustrings[i]->next;
    }
    if(args.q < 2){
      qsort(shustringArr,result->numShustrings[i],sizeof(shustringArr[0]),compareShustrings);
      for(j=0;j<result->numShustrings[i];j++){
	fprintf(fpout,"%d\t",j+1);
	fprintf(fpout,"%ld\t",shustringArr[j]->pos);
	fprintf(fpout,"%ld\t",shustringArr[j]->len);
	str = (char *)emalloc((shustringArr[j]->len+1)*sizeof(char));
	if(args.q == 0){
	  str= num2str(shustringArr[j]->word, shustringArr[j]->len, alphabet, str);
	  reverse(str);
	  fprintf(fpout,"%s",str);
	}
	fprintf(fpout,"\n");
      }
      free(shustringArr);
    }
    free(str);
  }
  if(args.o != NULL)
    fclose(fpout);
}

int compareShustrings(const void *v1, const void *v2){
  Shustring *s1, *s2;

  s1 = *(Shustring **)v1;
  s2 = *(Shustring **)v2;

  if(s1->pos < s2->pos){
    return -1;
  }else if(s2->pos == s1->pos){
    return 0;
  }else{
    return 1;
  }
}
