/***** findShustring.c *******************************************************
 * Description: 
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Thu Dec  7 12:55:46 2006.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <regex.h>
#include <unistd.h>
#include "DeepShallow/common.h"
#include "eprintf.h"
#include "interface.h"
#include "sequenceData.h"
#include "shulen.h"

void findGlobalShustrings(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp){
  Int64 min, i, j, k, l, lb, shuCount, numShu;
  Int64 *sl;
  FILE *fp;
  
  if(args->o)
    fp = efopen(args->o,"w");
  else
    fp = stdout;

  sl = getShulensWithoutSentinel(args,seq,sa,lcp);

  lb = 0;
  for(i=0;i<seq->numSeq;i++){
    shuCount = 0;
    min = INT_MAX;
    /* first pass across shulen array: find minimum length (per input sequence) */
    if(i)
      lb = seq->borders[i-1] + 1;      
    for(j=lb;j<seq->borders[i];j++){
      if(sl[j] < min && sl[j] > 0){
	min = sl[j];
	shuCount = 1;
      }else if(sl[j] == min)
	shuCount++;
    }
    /* second pass across shulen array: output shustrings of minimal length */
    if(min > 0 && min < INT_MAX){
      fprintf(fp,"#%s\t%ld\t%ld\t%ld\n",seq->headers[i],seq->borders[i]-lb,shuCount,min);
      fprintf(fp,"#num\tpos\tlen");
      if(!args->q)
	fprintf(fp,"\tseq");
      fprintf(fp,"\n");
      numShu = 1;
    if(i)
      lb = seq->borders[i-1] + 1;
    else
      lb = 0;
    for(j=lb;j<seq->borders[i];j++)
      if(sl[j] == min){
	if(args->n)
	  fprintf(fp,"%ld\t%ld\t%ld",numShu++,seq->pos[j]+1-lb,min);
	else
	  fprintf(fp,"%ld\t%ld\t%ld",numShu++,j+1-lb,min);
	if(!args->q){
	  fprintf(fp,"\t");
	  l = j + sl[j];
	  for(k=j;k<l;k++)
	    fprintf(fp,"%c",seq->seq[k]);
	}
	fprintf(fp,"\n");
      }
    }
  }
}

void findLocalShustrings(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp){
  regex_t re;
  Int64 i, j, retval, min, max, lb, count;
  Int64 *sl, numShu, k, l, len;
  FILE *fp;
  
  if(args->o)
    fp = efopen(args->o,"w");
  else
    fp = stdout;

  sl = getShulensWithoutSentinel(args,seq,sa,lcp);
  
  /* compile regex */
  if(regcomp(&re, args->l, REG_EXTENDED) != 0) {
    fprintf(stderr, "%s: Error compiling regular expression: %s\n", "shustring", args->l);
    exit(EXIT_FAILURE);
  }

  lb = 0;
  for(i=0;i<seq->numSeq;i++){
    if((retval = regexec(&re,seq->headers[i],0,NULL,0)) == 0){
      numShu = 1;
      /* First pass: set min and max shulen and count shustrings */
      if(i)
	lb = seq->borders[i-1] + 1;      
      min = INT_MAX;
      max = INT_MIN;
      count = 0;
      for(j=lb;j<seq->borders[i];j++){
	if(sl[j] > 0){
	  if(sl[j] < min)
	    min = sl[j];
	  if(sl[j] > max)
	    max = sl[j];
	  if(sl[j] <= args->M && sl[j] >= args->m)
	    count++;
	}
      }
      /* second pass: print out shustring positions */
      if(min < INT_MAX && min > 0){                      /* are there any shustrings at all? */
	if(i)
	  lb = seq->borders[i-1] + 1;
	else
	  lb = 0;
	if(i)
	  len = seq->borders[i] - seq->borders[i-1] - 1;
	else
	  len = seq->borders[i];
	fprintf(fp,"#%s\t%ld\t%ld\t",seq->headers[i],len,count);
	if(min > args->m)
	  fprintf(fp,"%ld",min);
	else
	  fprintf(fp,"%d",args->m);
	fprintf(fp,"<=l<=");
	if(max < args->M)
	  fprintf(fp,"%ld\n",max);
	else
	  fprintf(fp,"%d\n",args->M);
	fprintf(fp,"#pos\tlen");
	if(!args->q)
	  fprintf(fp,"\tseq");
	fprintf(fp,"\n");
	for(j=lb;j<seq->borders[i];j++){
	  if(sl[j] >= args->m && sl[j] <= args->M){
	    if(args->n)
	      fprintf(fp,"%ld\t%ld",seq->pos[j]+1-lb,sl[j]);
	    else
	      fprintf(fp,"%ld\t%ld",j+1-lb,sl[j]);
	    if(!args->q){
	      fprintf(fp,"\t");
	      l = j + sl[j];
	      for(k=j;k<l;k++)
		fprintf(fp,"%c",seq->seq[k]);
	    }
	    fprintf(fp,"\n");
	  }
	}
      }
    }
  }
}
	
   
