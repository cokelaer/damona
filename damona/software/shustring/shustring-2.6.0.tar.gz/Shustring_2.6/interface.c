/***** interface.c ************************************************
 * Description: Routine for gathering arguments from the command
 *              line.
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Sun Jun 20 13:12:10 2004.
 *
 * This file is part of shustring.
 *
 *   Shustring is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   Shustring is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with shustring; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *****************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "interface.h"
#include "eprintf.h"

Args *getArgs(int argc, char *argv[]){
  Args *args;
  char c;
  int arg;

  args = (Args *)emalloc(sizeof(Args));

  args->i = NULL;
  args->o = NULL;
  args->r = 0;
  args->g = 1;
  args->l = NULL;
  args->u = 0;
  args->n = 0;
  args->m = 0;
  args->p = 0;
  args->h = 0;
  args->e = 0;
  args->a = 0;
  args->M = INT_MAX;
  args->q = 0;
  args->f = -1;
  args->s = 0;
  args->d = 0;
  arg = 1;
  while(arg < argc){
    if(argv[arg][0] == '-'){
      c = argv[arg][1];
      switch(c){
	case 'i':                           /* input file */
	  args->i = argv[++arg];
	  break;
	case 'o':                           /* output file */
	  args->o = argv[++arg];
	  break;
	case 'l':                           /* sequence for local shustrings */
	  args->l = argv[++arg];
	  if(args->l == NULL || args->l[0] == '-'){
	    printf("ERROR [shustring]: -l requires regex as argument\n");
	    args->e = 1;
	    return args;
	  }
	  break;
	case 'm':                           /* min. local shustring length */
	  args->m = atoi(argv[++arg]);
	case 'n':                           /* nucleotide sequence */
	  args->n = 1;
	  break;
	case 'a':                           /* hash option */
	  args->a = 1;
	  break;
	case 'M':                           /* max. local shustring length */
	  args->M = atoi(argv[++arg]);
	  break;
	case 'f':                           /* constant hash key */
	  args->f = atoi(argv[++arg]);
	  break;
	case 'r':                           /* include reverse complement */
	  args->r = 1;
	  args->n = 1;
	  break;
	case 's':                           /* sort local shustrings? */
	  args->s = 1;
	  break;
	case 'q':                           /* quiet? */
	  args->q = 1;
	  break;
	case 'u':                           /* preserve UPAC nomenclature */
	  args->u = 1;
	  break;
	case 'h':                           /* print help */
	  args->h = 1;
	  break;
	case 'p':                           /* print help */
	  args->p = 1;
	  break;
	default:
	  printf("# unknown argument: %c\n",c);
	  args->e = 1;
	  return args;
      }
      arg++;
    }
  }
  if(args->l == NULL && (args->M != INT_MAX || args->m != 0))
    args->e = 1;
  if(!(args->q == 0 || args->q ==1 || args->q ==2))
    args->e = 1;
  if(args->f > 0 && !args->a)
    args->e = 1;
  if(args->i == NULL && args->a)
    args->e = 1;
  if(args->l != NULL && args->a)
    args->e = 1;
  if(args->a && args->i == NULL){
    printf("ERROR [shustring]: need to use -i in hash mode (-a)\n");
    args->e = 1;
  }
  return args;
}


void printUsage(char *version){
  printf("shustring version %s, copyright (c) 2005-2008 Bernhard Haubold & Thomas Wiehe\n", version);
  printf("\tdistributed under the GNU General Public License\n");
  printf("purpose: compute shortest unique substrings\n");
  printf("usage: shustring [options]\n");
  printf("options\n");
  printf("  input/output\n");
  printf("\t[-i <FILE> input file; default: FILE=stdin]\n");
  printf("\t[-o <FILE> write output to FILE; default: FILE=stdout]\n");
  printf("  suffix array mode\n");		       
  printf("\t[-l <PATTERN> - print local shustrings for PATTERN; default: global]\n");	    
  printf("\t[-M <NUM> shustring length <= NUM (with -l only); default: find all]\n");
  printf("\t[-m <NUM> shustring length >= NUM (with -l only); default: find all]\n");		
  printf("  hash mode\n");
  printf("\t[-a hash mode (requires -i, implies -n); default: suffix array mode]\n");
  printf("\t[-f <NUM> fixed word length NUM (with -a only); default: look for shortest]\n");
  printf("  general\n");
  printf("\t[-q quiet - do not print shustrings; default: print shustrings]\n");
  printf("\t[-n nucleotide sequence (DNA); default: arbitrary ASCII strings]\n");
  printf("\t[-r include reverse complement (implies -n); default: only forward strand]\n");
  printf("\t[-u preserve IUPAC nomenclature in nucleotide sequences; default: convert to ACGT]\n");
  printf("\t[-p print information about program]\n");			     
  printf("\t[-h print this help message]\n");
}

void printSplash(char *version){
  printf("********************************************\n");
  printf("*              SHUSTRING %s               *\n",version);
  printf("*        SHortest Unique Substrings        *\n");
  printf("*                    by                    *\n");
  printf("*      Bernhard Haubold & Thomas Wiehe     *\n");
  printf("*------------------------------------------*\n");
  printf("*               REFERENCE                  *\n");
  printf("* Haubold, B., Pierstorff, N., M\"oller,    *\n");
  printf("* F., Wiehe, T. (2005). Genome comparison  *\n");
  printf("* without alignment using shortest unique  *\n");
  printf("* substrings. BMC Bioinformatics, 6:123.   *\n");
  printf("*                                          *\n");
  printf("*              CONTACT                     *\n");
  printf("* Code maintained by Bernhard Haubold,     *\n");
  printf("* haubold@evolbio.mpg.de                   *\n");
  printf("*                                          *\n");
  printf("*           ACKNOWLEDGEMENT                *\n");
  printf("* SHUSTRING is based on the dss_sort       *\n");
  printf("* library by G. Manzini; for further       *\n");
  printf("* details see:  G. Manzini, P. Ferragina   *\n");
  printf("* (2002). Engineering a lightweight suffix *\n");
  printf("* array construction algorithm. Proc. 10th *\n");
  printf("* European Symposium on  Algorithms (ESA   *\n");
  printf("* '02'). Springer Verlag Lecture Notes in  *\n");
  printf("* Computer Science n. 2461, pp 698-710.    *\n");
  printf("* www.mfn.unipmn.it/~manzini/lightweight   *\n");
  printf("*                                          *\n");
  printf("*              LICENSE                     *\n");
  printf("* SHUSTRING is distributed under the GNU   *\n");
  printf("* General Public License. You should have  *\n");
  printf("* received a copy of the licence together  *\n");
  printf("* with this software. If not, see          *\n");
  printf("* http://www.gnu.org/licenses/.            *\n");
  printf("********************************************\n");
}
