/***** shustring.c ************************************************
 * Description: Compute shortest unique substrings.
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Fri Apr 15 13:08:35 2005.
 *
 * This file is part of shustring.
 *
 *   Shustring is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   Shustring is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with shustring; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *****************************************************************/
#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include <time.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

#include "DeepShallow/common.h"
#include "DeepShallow/ds_ssort.h"
#include "DeepShallow/bwt_aux.h"
#include "DeepShallow/lcp_aux.h"

#include "eprintf.h"
#include "interface.h"
#include "sequenceData.h"
#include "stringUtil.h"
#include "shulen.h" 
#include "shustring.h"
#include "hash.h"

int main(int argc, char *argv[]){
  char *version;
  Sequence *sequence = NULL;
  Sequence *reverseStrand = NULL;
  Int64 i;
  Args *args;
  Int64 overshoot;
  Int64 *sa, *lcp;
  Int64 occ[ALPHA_SIZE];
  unsigned char *textu;
  int fd;
      
  version = "2.6";
  setprogname2("shustring");

  args = getArgs(argc, argv);

  if(args->h == 1){ 
    printUsage(version);
    return 0; 
  }else if(args->e == 1){
    printUsage(version);
    return -1;
  }else if(args->p){
    printSplash(version);
    exit(0);
  }

  if(args->a){
    runHash(*args);
    exit(0);
  }
  
  if(args->i != NULL){
    fd = open(args->i,0);
  }else{
    fd = 0;
  }
  if(fd < 0){
    printf("ERROR [shustring]: could not open input file %s\n",args->i);
    return -1;
  }
  fflush(NULL);
  sequence = readFasta(fd);
  close(fd);
  fflush(NULL);
  if((args->n || args->r) && ! args->u){
    fflush(NULL);
    convertToAcgt(sequence);
    fflush(NULL);
  }
  strtoupper(sequence->seq);
  fflush(NULL);
  if(args->r){
    reverseStrand = revcomp(sequence);
    sequence->len += sequence->len;
    sequence->seq = (char *)erealloc(sequence->seq, (sequence->len+1)*sizeof(char));
    strcat(sequence->seq,reverseStrand->seq);
    freeSequence(reverseStrand);
  }
  fflush(NULL);
  /* init ds suffix sort routine (cf. DeepShallow/testlcp.c) */
  overshoot = init_ds_ssort(500,2000);
  if(overshoot==0)
    eprintf("ERROR (shustring.c): ds initialization failed.\n");
  sa = (Int64 *)emalloc((sequence->len+1) * sizeof(Int64));
  sequence->seq = (char *)erealloc(sequence->seq,(sequence->len+overshoot) * sizeof(unsigned char));
  textu = (unsigned char *)sequence->seq;
  fflush(NULL);
  ds_ssort(textu, sa+1, sequence->len);
  fflush(NULL);
  for(i=0;i<ALPHA_SIZE;i++)
    occ[i] = 0;
  for(i=0;i<sequence->len;i++)
    occ[textu[i]]++;
  lcp = _lcp_sa2lcp_9n(textu,sequence->len,sa,occ);
  if(args->l)
    findLocalShustrings(args,sequence,sa,lcp); 
  else
    findGlobalShustrings(args,sequence,sa,lcp);

  return 0; 
}


 
