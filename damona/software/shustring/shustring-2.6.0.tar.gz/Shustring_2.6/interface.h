/***** interface.h ************************************************
 * Description: Header file for user interface.
 * Author: Bernhard Haubold, bernhard.haubold@fh-weihenstephan.de
 * File created on Sun Jun 20 13:07:28 2004.
 *****************************************************************/

/* define argument container */
typedef struct args{
  char *i;          /* name of first input file */
  char *o;          /* name of output file */
  int M;            /* max. shustring length */
  int m;            /* min. shustring length */
  int a;            /* hash option */
  int p;            /* print program information */
  int g;            /* global shustrings */
  int d;            /* debug output? */
  char *l;          /* identifier of string for local shustrings */
  int r;            /* reverse sequence? */
  int f;            /* fixed word length */
  int q;            /* quiet mode? */
  int s;            /* sort local shustrings? */
  int n;            /* nucleotide */
  int u;            /* preserve UPAC nomenclature? */
  int h;            /* help message? */
  int e;            /* error message? */
} Args;

Args *getArgs(int argc, char *argv[]);
void printUsage(char *version);
void printSplash(char *version);
