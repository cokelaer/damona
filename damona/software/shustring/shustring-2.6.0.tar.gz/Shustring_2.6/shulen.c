/***** shulen.c **************************************************************
 * Description: Compute the lengths of shortest unique substrings.
 * Author: Bernhard Haubold, haubold@evolbio.mpg.de
 * File created on Wed Dec  6 16:12:32 2006.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
 *****************************************************************************/
#include <stdio.h>
#include <limits.h>
#include "DeepShallow/common.h"
#include "sequenceData.h"
#include "eprintf.h"
#include "interface.h"
#include "shulen.h"

Int64 *removeNonDna(Int64 *sl, Sequence *seq);

/* getShulensWithoutSentinel: return array of true shustring lengths */
Int64 *getShulensWithoutSentinel(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp){
  Int64 i, j, min, *sl;

  sl = getRawShulens(args, seq, sa, lcp);
  /* filter out shulens that cross string borders */
  min = 0;
  for(i=0;i<seq->numSeq;i++){
    if(i)
      min = seq->borders[i-1];
    for(j=seq->borders[i]-1;j>min;j--)
      if(j + sl[j] > seq->borders[i])
	sl[j] = -1;
      else
	break;
  }
/*   if(args->n) */
/*     sl = removeNonDna(sl,seq); */

  return sl;
}

Int64 *removeNonDna(Int64 *sl, Sequence *seq){
  int *dic;
  Int64 i, j, min;

  dic = NULL;
  dic = getRestrictedDnaDictionary(dic);
  min = 0;
  for(i=0;i<seq->numSeq;i++){
    for(j=min;j<seq->borders[i];j++)
      /* check that shustring neither starts nor ends in a non-canonical character */
      if(dic[(int)seq->seq[j]] < 0 || dic[(int)seq->seq[j+sl[j]-1]] < 0)
	sl[j] = -1;
    min = seq->borders[i]+1;
  }
  
  return sl;
}

Int64 *getRawShulens(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp){
  Int64 i, arrayLen, seqLen;
  Int64 *sl;
  
  if(args->r)
    seqLen = seq->len/2;
  else
    seqLen = seq->len;
  arrayLen = seq->len;
  sl = (Int64 *)emalloc(seqLen*sizeof(Int64));
  for(i=2;i<arrayLen;i++)
    if(sa[i]<seqLen){
      if(lcp[i+1] < lcp[i])
	sl[sa[i]] = lcp[i] + 1;
      else
	sl[sa[i]] = lcp[i+1] + 1;
    }
  if(sa[i] < seqLen)
    sl[sa[i]] = lcp[i] + 1;
  if(sa[1] < seqLen)
    sl[sa[1]] = lcp[2] + 1;
  return sl;
}

/* getShulensWithSentinel: return shulens as if each sequence was terminated by a unique character. */
Int64 *getShulensWithSentinel(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp){
  Int64 i, j, min, *sl;
  
  sl = getRawShulens(args, seq, sa, lcp);

  /* prune shulens that cross string borders */
  min = 0;
  for(i=0;i<seq->numSeq;i++){
    if(i)
      min = seq->borders[i-1];
    for(j=seq->borders[i]-1;j>=min;j--)
      if(j + sl[j] > seq->borders[i] + 1)
	sl[j] = seq->borders[i] - j + 2;
      else
	break;
  }
/*   if(args->n) */
/*     sl = removeNonDna(sl, seq); */

  return sl;
}
