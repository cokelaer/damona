/***** hash.h *****************************************************
 * Description: 
 * Author: Bernhard Haubold, bernhard.haubold@fh-weihenstephan.de
 * File created on Wed Apr 20 12:34:07 2005.
 *****************************************************************/
#define MAXLINE 1000
#define NAMELENGTH 30

/* represents a single string; the string is addressed via its array index */
typedef struct count{
  int position;
  int stringId;
  int len;
  short int count;
  unsigned int isForward : 1;
} Count;

typedef struct countTable{
  int wordLen;    /* length of hash keys; 4^wordLength = size of array */
  int occupancy;  /* the number of slots filled */
  int size;       /* the size of the array */
  Count *array;   /* array of counts */
} CountTable;

char *num2str(int word, int wordLength, char *dic, char *str);
void runHash(Args args);
void outputHash(ShustringResult *result, Args args);
ShustringResult *constantHash(Args args);
int countUniqueWords(CountTable *table, char *str, int seqid, int numUnique, int rev);
int collectShustrings(CountTable *table, ShustringResult *result);
void initializeCountTable(CountTable *table);
void setCase(Args args, ShustringResult *result);
ShustringResult *iterativeHash(Args args);
int compareShustrings(const void *, const void *);
