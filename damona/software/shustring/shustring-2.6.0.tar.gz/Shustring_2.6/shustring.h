/***** shustring.h ************************************************
 * Description: Header file for shustring program
 * Author: Bernhard Haubold, bernhard.haubold@fh-weihenstephan.de
 * File created on Mon Feb 21 14:40:13 2005.
 *****************************************************************/
/* definition of single shustring, element of list */ typedef struct shustring{
  Int64 pos;                    /* position */
  Int64 posR;                   /* reverse position */
  Int64 len;                    /* length */
  Int64 stringId;               /* identifyer of string of origin */
  Int64 word;                   /* the integer representing the shustring */
  unsigned int isForward : 1; /* shustring is situated of forward strand */
  struct shustring *next;     /* pointer to next element of list */
} Shustring;


typedef struct shustringResult{
  char **names;             /* sequence names */
  Shustring **shustrings;   /* array of shustring lists, one list for each sequence */
  Int64 numStrings;           /* number of input strings */
  Int64 *numShustrings;       /* number of shustrings per input list */ 
  Int64 *strLengths;          /* array of input string lengths */
  short *coverIndex;        /* input string covered by a shustring? */
  Int64 numCovered;           /* number of sequences covered by shustrings */
  unsigned int isUpper : 1; /* uppercase */
} ShustringResult;

void findGlobalShustrings(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp);
void findLocalShustrings(Args *args, Sequence *seq, Int64 *sa, Int64 *lcp);  

